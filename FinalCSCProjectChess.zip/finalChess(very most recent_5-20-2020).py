#######################################################################################################
# Name: Jonathan Trahan, Timothy Huhn, John Norris
# Date: 5/20/20
# Description: Chess (Game Strategies)
#######################################################################################################
####################################  HOW TO PLAY/ MANUAL  ############################################
#
# This is a python game meant to be played on a Raspberry Pi, its screen size is 800 x 480 by default.
# This virtual chess game was made for our CSC 132 Project in Spring 2020. The chess game is meant
# to be played as if it were a vitual game of chess and will not keep track of whose turn it is.
#
# To start the game, run the program. White will go first, next black, then white, and so on.
#
# To select a piece, double click on the desired piece. To move/attack click on the green dots
# or red boxes. Green dots will appear from a selected piece to indicate where a piece can move.
# Red boxes will appear on potential targets for the selected piece to take. To cancel any action
# with a selected piece selected a tile without a piece nor any green dots.
#
# Taken pieces will appear on the right side and currently stack on each other. The taken pieces
# are also put into a list in the shell.
#
# The shell only contains testing print statements and is only for tracking certain actions for
# develepoment and bug fixing.
#
# Thank you and have fun!
#
#######################################################################################################

import pygame
import sys
import Tkinter
from pygame.locals import *

# Function to dsiplay the contents of the game
def Display():
    DISPLAYSURF.fill(WHITE)
    DISPLAYSURF.blit(golfBackground,(0, 0))
    DISPLAYSURF.blit(chessboardIMG,(BoardDisplacement, 0))

# pieces class
class Pieces(pygame.sprite.Sprite):
        # constructor
        def __init__(self, piece, position):
            pygame.sprite.Sprite.__init__(self)
            self.image = piece
            self.rect = self.image.get_rect()
            self.rect.topleft = position

        def update(self, fromTile, fromPiece, toTile, toPiece, availableMoves, availableAttacks):
            if(fromPiece == "e" or fromPiece == None):
                pass
            elif (toTile in availableMoves or toTile in availableAttacks):
                # get tile cords
                X,Y = TileCords[toTile]
                # get cords for side of board
                SX,SY = TileCords["H8"]
                SX = SX + 60
                # place white/black in their designated side
                if (toPiece[0:5] == "WHITE"):
                    ALL_PIECES[toPiece].rect.x = 665
                    ALL_PIECES[toPiece].rect.y = SY
                elif (toPiece[0:5] == "BLACK"):
                    ALL_PIECES[toPiece].rect.x = 725
                    ALL_PIECES[toPiece].rect.y = SY

                # move the from piece to x,y gotten from toTile
                ALL_PIECES[fromPiece].rect.x = X
                ALL_PIECES[fromPiece].rect.y = Y
                if toPiece != "e":
                    print fromPiece+" moves from "+fromTile+" to "+toTile+" and takes "+toPiece
                print
                print "whitesTakenPieces: ",
                for i in whitesTakenPieces:
                    print i + ",",
                print
                print
                print "blacksTakenPieces: ",
                for i in blacksTakenPieces:
                    print i + ",",
                print

                # if the king is taken by either color then the game ends
                for i in whitesTakenPieces:
                    if "KING" in i:
                        pygame.quit()
                        sys.exit()
                        pygame.display.update()

                for i in blacksTakenPieces:
                    if "KING" in i:
                        pygame.quit()
                        sys.exit()
                        pygame.display.update()
                    
                    
                
                # change whats in the fromTile to "e" or empty since piece was moved
                TileSpace[toTile] = fromPiece
                TileSpace[fromTile] = "e"
                
                if toTile in availableMoves:
                    X,Y = TileCords[toTile]
                    
                    ALL_PIECES[fromPiece].rect.x = X
                    ALL_PIECES[fromPiece].rect.y = Y
                    print fromPiece+" moves from "+fromTile+" to "+toTile
                    
                    TileSpace[toTile] = fromPiece
                    TileSpace[fromTile] = "e"

            print
                

def getInput():
    print
    fromSquareChosen = False
    toSquareChosen = False
    while (fromSquareChosen == False or toSquareChosen == False):
        #print "SQ1: ", fromSquareChosen, toSquareChosen
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
                pygame.display.update()
        
            # when a tile is clicked, determine if piece is on tile
            # if a piece is on the clicked tile, confirm that a mouse button was clicked
            if event.type == MOUSEBUTTONDOWN:
                print "MBD"
                mousex, mousey = event.pos
                tile, piece = TilePressed(mousex, mousey)
                if(piece == None):
                    print "None: ",piece
                    pass
                elif (fromSquareChosen == False and toSquareChosen == False):
                    if (piece != "e"):
                        print "Tile,Piece1: ", tile, piece
                        fromTile = tile
                        fromPiece = piece
                        color = fromPiece[0:5]
                        # get availableMoves
                        if ("PAWN" in fromPiece):
                            availableMoves, availableAttacks = PawnMovement(color, fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        if ("ROOK" in fromPiece):
                            availableMoves, availableAttacks = RookMovement(fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        if ("KNIGHT" in fromPiece):
                            availableMoves, availableAttacks = KnightMovement(fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        if ("BISHOP" in fromPiece):
                            availableMoves, availableAttacks = BishopMovement(fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        if ("QUEEN" in fromPiece):
                            availableMoves, availableAttacks = QueenMovement(fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        if ("KING" in fromPiece):
                            availableMoves, availableAttacks = KingMovement(fromTile)
                            for tile in availableMoves:
                                if tile != None and tile != "e":
                                    DrawDot(tile)
                            for tile in availableAttacks:
                                if tile != None and tile != "e":
                                    DrawHitbox(tile, fromPiece)
                            
                        
                        fromSquareChosen = True
                elif (fromSquareChosen == True and toSquareChosen == False):
                    if piece == "e":
                        print "Tile,Piece2: ", tile, piece
                        toTile = tile
                        toPiece = piece
                            
                        toSquareChosen = True
                    elif (piece != "e"):
                        if (fromPiece[0:5] == piece[0:5]):
                            print "You can't take your own piece"
                        else:
                            print "Tile,Piece2: ", tile, piece
                            toTile = tile
                            toPiece = piece
                            toSquareChosen = True
                            if (fromPiece[0:5] == "WHITE"):
                                whitesTakenPieces.append(toPiece)
                                print "White appended: ", toPiece
                                print
                            elif (fromPiece[0:5] == "BLACK"):
                                blacksTakenPieces.append(toPiece)
                                print "Black appended: ", toPiece
                                print
    
    print "FromToSquare: ", fromSquareChosen, toSquareChosen
    print
    return fromTile,fromPiece,toTile,toPiece, availableMoves, availableAttacks

# movement functions
def PawnMovement(color, fromTile):
    availableMoves = []
    availableAttacks = []
    
    if (color == "WHITE"):
        # Pawn First move condition
        if ("2" in fromTile):
            for i in range(1,3):
                toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])+i))
                if (TileSpace[toTile] == "e"): 
                    availableMoves.append(toTile)
                
                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num += 1
                LIndex += 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num += 1
                LIndex -= 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)
                            
        # Normal move condition
        else:
            if fromTile[1] != "8":
                toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])+1))
                if (TileSpace[toTile] == "e"): 
                    availableMoves.append(toTile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num += 1
                LIndex += 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num += 1
                LIndex -= 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

                
    elif(color == "BLACK"):
        if ("7" in fromTile):
             for i in range(1,3):
                toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])-i))
                if (TileSpace[toTile] == "e"): 
                    availableMoves.append(toTile)
                
                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num -= 1
                LIndex += 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num -= 1
                LIndex -= 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

        else:
            if fromTile[1] != "1":
                toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])-1))
                if (TileSpace[toTile] == "e"): 
                    availableMoves.append(toTile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num -= 1
                LIndex += 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

                # 0-7 X
                LIndex = xAxis.index(fromTile[0])
                # 1-8 Y
                num = int(fromTile[1])
                num -= 1
                LIndex -= 1
                print LIndex, num
                if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
                    tile = xAxis[LIndex] + str(num)
                    print tile
                    if TileSpace[tile] != "e":
                        availableAttacks.append(tile)

    else:
        pass
    
    return availableMoves, availableAttacks

def RookMovement(fromTile):
    availableMoves = []
    availableAttacks = []

    # Move Down
    for i in range(int(fromTile[1])-1, 0, -1):
        toTile = fromTile.replace(fromTile[1], str(xAxis.index(xAxis[i])))
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Up
    for i in range(int(fromTile[1]), 8):
        toTile = fromTile.replace(fromTile[1], str(xAxis.index(xAxis[i])+1))
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Right
    tempIndex = xAxis.index(fromTile[0])
    for i in (xAxis[(tempIndex + 1):]):
        toTile = fromTile.replace(fromTile[0], i)
        if (TileSpace[toTile] == "e"):
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Left
    tempIndex = xReverse.index(fromTile[0])
    for i in (xReverse[(tempIndex + 1):]):
        toTile = fromTile.replace(fromTile[0], i)
        if (TileSpace[toTile] == "e"):
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break
        
    return availableMoves, availableAttacks

def KnightMovement(fromTile):
    availableMoves = []
    availableAttacks = []
    
    # lists for piece's movements
    #xAxis = ["A", "B", "C", "D", "E", "F", "G", "H"]
    #xReverse = ["H", "G", "F", "E", "D", "C", "B", "A"]
    
    # up 2 right 1
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num -= 2
    LIndex += 1
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # up 1 right 2
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num -= 1
    LIndex += 2
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # down 1 right 2
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num += 1
    LIndex += 2
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # down 2 right 1
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num += 2
    LIndex += 1
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # down 2 left 1
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num += 2
    LIndex -= 1
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # down 1 left 2
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num += 1
    LIndex -= 2
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # up 1 left 2
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num -= 1
    LIndex -= 2
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
            

    # up 2 left 1
    # 0-7 X
    LIndex = xAxis.index(fromTile[0])
    # 1-8 Y
    num = int(fromTile[1])
    num -= 2
    LIndex -= 1
    print LIndex, num
    if LIndex <=7 and num <= 8 and LIndex >=0 and num >= 1:
        tile = xAxis[LIndex] + str(num)
        print tile
        if TileSpace[tile] == "e":
            availableMoves.append(tile)
        elif TileSpace[tile] != "e":
            availableAttacks.append(tile)
               

    return availableMoves, availableAttacks


def BishopMovement(fromTile):
    availableMoves = []
    availableAttacks = []

    # up right
    LIndex = xAxis.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num <= 7:
            num += 1
            tile = xAxis[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break
    # down right
    LIndex = xAxis.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num >= 2:
            num -= 1
            tile = xAxis[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break
    # up left
    LIndex = xReverse.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num <= 7:
            num += 1
            tile = xReverse[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break

    # down left
    LIndex = xReverse.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num >= 2:
            num -= 1
            tile = xReverse[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break

    return availableMoves, availableAttacks


def QueenMovement(fromTile):
    availableMoves = []
    availableAttacks = []
    
    # Move Down
    for i in range(int(fromTile[1])-1, 0, -1):
        toTile = fromTile.replace(fromTile[1], str(xAxis.index(xAxis[i])))
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Up
    for i in range(int(fromTile[1]), 8):
        toTile = fromTile.replace(fromTile[1], str(xAxis.index(xAxis[i])+1))
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Right
    tempIndex = xAxis.index(fromTile[0])
    for i in (xAxis[(tempIndex + 1):]):
        toTile = fromTile.replace(fromTile[0], i)
        if (TileSpace[toTile] == "e"):
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # Move Left
    tempIndex = xReverse.index(fromTile[0])
    for i in (xReverse[(tempIndex + 1):]):
        toTile = fromTile.replace(fromTile[0], i)
        if (TileSpace[toTile] == "e"):
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            break

    # up right
    LIndex = xAxis.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num <= 7:
            num += 1
            tile = xAxis[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break
    # down right
    LIndex = xAxis.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num >= 2:
            num -= 1
            tile = xAxis[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break
    # up left
    LIndex = xReverse.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num <= 7:
            num += 1
            tile = xReverse[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break

    # down left
    LIndex = xReverse.index(fromTile[0])
    num = int(fromTile[1])
    for i in range(LIndex, 8):
        print LIndex, i, num
        if i <=6 and num >= 2:
            num -= 1
            tile = xReverse[i+1] + str(num)
            print tile
            if TileSpace[tile] == "e":
                availableMoves.append(tile)
            elif TileSpace[tile] != "e":
                availableAttacks.append(tile)
                break
    
    return availableMoves, availableAttacks
##    pass

def KingMovement(fromTile):
    availableMoves = []
    availableAttacks = []

    # Move Up
    toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])+1))
    if (int(toTile[1]) <= 8):
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            pass
    else:
        pass

    # Move Down
    toTile = fromTile.replace(fromTile[1], str(int(fromTile[1])-1))
    if (int(toTile[1]) >= 1):
        if (TileSpace[toTile] == "e"): 
            availableMoves.append(toTile)
        else:
            availableAttacks.append(toTile)
            pass
    else:
        pass

    # Move Right
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex <= 6:
        toTile = fromTile.replace(fromTile[0], xAxis[(tempIndex + 1)])
        if(xAxis.index(toTile[0]) <= 7):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    # Move Left
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex >= 1:
        toTile = fromTile.replace(fromTile[0], xAxis[(tempIndex - 1)])
        if(xAxis.index(toTile[0]) >= 0):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    # Move North-East
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex <= 6:
        toTile = str(xAxis[(tempIndex + 1)] + str(int(fromTile[1])+1))
        if(xAxis.index(toTile[0]) <= 7) and (int(toTile[1]) <= 8):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    # Move South-East
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex <= 6:
        toTile = str(xAxis[(tempIndex + 1)] + str(int(fromTile[1])-1))
        if(xAxis.index(toTile[0]) <= 7) and (int(toTile[1]) >= 1):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    # Move North-West
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex >= 1:
        toTile = str(xAxis[(tempIndex - 1)] + str(int(fromTile[1])+1))
        if(xAxis.index(toTile[0]) >= 1) and (int(toTile[1]) <= 8):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    # Move South-West
    tempIndex = xAxis.index(fromTile[0])
    if tempIndex >= 1:
        toTile = str(xAxis[(tempIndex - 1)] + str(int(fromTile[1])-1))
        if(xAxis.index(toTile[0]) >= 1) and (int(toTile[1]) >= 1):
            if (TileSpace[toTile] == "e"): 
                availableMoves.append(toTile)
            else:
                availableAttacks.append(toTile)
                pass
        else:
           pass

    
    return availableMoves, availableAttacks
##    pass

# draws a green dot
def DrawDot(tile):
    # green dot
    image = "GREEN_DOT"
    x,y = TileCords[tile]
    print tile, image, x, y
    DISPLAYSURF.blit(GREEN_DOT,(x, y))
    pygame.display.update()

def DrawHitbox(tile, fromPiece):
    # red box
    toPiece = TileSpace[tile]
    toPiece[0:5]
    if(toPiece[0:5] == fromPiece[0:5]):
        pass
    else:
        image = "RED_BOX"
        x,y = TileCords[tile]
        print tile, image, x, y
        DISPLAYSURF.blit(RED_BOX,(x, y))
        pygame.display.update()

# piece ID maker
def PieceIDMaker(tile, image, i):
    x,y = TileCords[tile]
    print tile, image, x, y
    PieceID = image + "_" + i
    ALL_PIECES[PieceID] = Pieces(PieceImages[image],(x,y))
    # add to sprites
    all_sprites.add(ALL_PIECES[PieceID])
    TileSpace[tile] = PieceID


# Default placement of chess pieces
def DefaultPieces():
        ## White/Black Pawn
        for i in ["A", "B", "C", "D", "E", "F", "G", "H"]:
                # black pawn
                tile = (i + "7")
                image = "BLACK_PAWN"
                PieceIDMaker(tile, image, i)
                
                # white pawn
                tile = (i + "2")
                image = "WHITE_PAWN"
                PieceIDMaker(tile, image, i)

        ## White/Black Rook
        for i in ["A", "H"]:
                # black rook
                tile = (i + "8")
                image = "BLACK_ROOK"
                PieceIDMaker(tile, image, i)
                
                # white rook
                tile = (i + "1")
                image = "WHITE_ROOK"
                PieceIDMaker(tile, image, i)

        ## White/Black Knight
        for i in ["B", "G"]:
                # black knight
                tile = (i + "8")
                image = "BLACK_KNIGHT"
                PieceIDMaker(tile, image, i)
                
                # white knight
                tile = (i + "1")
                image = "WHITE_KNIGHT"
                PieceIDMaker(tile, image, i)

        ## White/Black Bishop
        for i in ["C", "F"]:
                # black bishop
                tile = (i + "8")
                image = "BLACK_BISHOP"
                PieceIDMaker(tile, image, i)
                
                # white bishop
                tile = (i + "1")
                image = "WHITE_BISHOP"
                PieceIDMaker(tile, image, i)

        ## Black/White Queen
        i = "D"
        # black queen
        tile = (i + "8")
        image = "BLACK_QUEEN"
        PieceIDMaker(tile, image, i)
        
        # white queen
        tile = (i + "1")
        image = "WHITE_QUEEN"
        PieceIDMaker(tile, image, i)


        ## Black/White King
        i = "E"
        # black king
        tile = (i + "8")
        image = "BLACK_KING"
        PieceIDMaker(tile, image, i)
        
        # white king
        tile = (i + "1")
        image = "WHITE_KING"
        PieceIDMaker(tile, image, i)

# gets what tile the mouse clicks
def TilePosition(MX, MY):
    x = ""
    y = ""
    for i in range(0, 8):
        if (MX > XLeft[i] and MX < XRight[i]):
            x = X_keys[i]

        if (MY > YTop[i] and MY < YBottom[i]):
            y = Y_keys[i]
    if (x in X_keys and y in Y_keys):
        return x+y

# sees what to do based on what is in clicked tile, returns what was on the tile
def TilePressed(MX, MY):
    # gets the tile that was clicked
    tile = TilePosition(MX, MY)
    # gets what is in the tile
    if tile in TileSpace.keys():
        piece = TileSpace[tile]
    else:
        piece = None

    return tile, piece


#######
# main
#######
# Initialie pygame
pygame.init()

# Screen Settings
WIDTH = 800
HEIGHT = 480
BoardDisplacement = (WIDTH-HEIGHT)/2
FPS = 30
WHITE = (255, 255, 255)

# Dictionary for every piece, DO NOT REMOVE WILL DESTABLIZE EVERYTHING
ALL_PIECES = {}
whitesTakenPieces = []
blacksTakenPieces = []
#whitesTakenPieces.append("whitesTakenPieces: ")
#blacksTakenPieces.append("blacksTakenPieces: ")

# green dot checker
availableMoves = []
availableAttacks = []


# lists for piece's movements
xAxis = ["A", "B", "C", "D", "E", "F", "G", "H"]
xReverse = ["H", "G", "F", "E", "D", "C", "B", "A"]

# X-Axis Pixels
X_Axis = {"H":442,"G":384,"F":326,"E":268,"D":210,"C":152,"B":95,"A":37}

# Y-Axis Pixels set
Y_Axis = {"8":37,"7":95,"6":152,"5":210,"4":268,"3":326,"2":384,"1":442}

# Boundry of tiles
XLeft = [BoardDisplacement + x - 25 for x in (X_Axis.values())]
XRight = [BoardDisplacement + x + 25 for x in (X_Axis.values())]
YTop = [x - 25 for x in (Y_Axis.values())]
YBottom = [x + 25 for x in (Y_Axis.values())]

# x and y cords for the green sides
leftSide_X = [25, 85]
rightSide_X = [665, 725]
Sides_Y = [12, 70, 127, 185, 243, 301, 359, 417]

RightSideCords = []
for i in rightSide_X:
        for j in Sides_Y:
                RightSideCords.append((i,j))

LeftSideCords = []
for i in leftSide_X:
        for j in Sides_Y:
                LeftSideCords.append((i,j))

# get list of X_Axis and Y_Axis keys
X_keys = (X_Axis.keys())
Y_keys = (Y_Axis.keys())

# cords to place a piece
TileCords = {}
for i in X_keys:
        for j in Y_keys:
                TileCords[i+j] = (XLeft[X_keys.index(i)], YTop[Y_keys.index(j)])
                
# dictionary of what's in a tile
TileSpace = {}
for i in X_keys:
        for j in Y_keys:
                TileSpace[i+j] = "e"

# create window
DISPLAYSURF = pygame.display.set_mode((WIDTH, HEIGHT), 0, 32)
pygame.display.set_caption('Chessboard')
clock = pygame.time.Clock()

## images
# Background Pics
chessboardIMG = pygame.image.load('ChessBoardv2.jpg')
golfBackground = pygame.image.load('GreenBackground.gif')

# White Chess Piece GIFs
WHITE_ROOK = pygame.image.load('white_rook.gif')
WHITE_QUEEN = pygame.image.load('white_queen.gif')
WHITE_PAWN = pygame.image.load('white_pawn.gif')
WHITE_KNIGHT = pygame.image.load('white_knight.gif')
WHITE_KING = pygame.image.load('white_king.gif')
WHITE_BISHOP = pygame.image.load('white_bishop.gif')

# Black Chess Piece GIFs
BLACK_ROOK = pygame.image.load('black_rook.gif')
BLACK_QUEEN = pygame.image.load('black_queen.gif')
BLACK_PAWN = pygame.image.load('black_pawn.gif')
BLACK_KNIGHT = pygame.image.load('black_knight.gif')
BLACK_KING = pygame.image.load('black_king.gif')
BLACK_BISHOP = pygame.image.load('black_bishop.gif')

# Green dot to mark where a piece can move
GREEN_DOT = pygame.image.load("green_dot.gif")

# Red box to indicate attack
RED_BOX = pygame.image.load("red_square.png")

# adds images to dictionary
PieceImages = {}
PieceImages["WHITE_ROOK"] = WHITE_ROOK
PieceImages["WHITE_QUEEN"] = WHITE_QUEEN
PieceImages["WHITE_PAWN"] = WHITE_PAWN
PieceImages["WHITE_KNIGHT"] = WHITE_KNIGHT
PieceImages["WHITE_KING"] = WHITE_KING
PieceImages["WHITE_BISHOP"] = WHITE_BISHOP
PieceImages["BLACK_ROOK"] = BLACK_ROOK
PieceImages["BLACK_QUEEN"] = BLACK_QUEEN
PieceImages["BLACK_PAWN"] = BLACK_PAWN
PieceImages["BLACK_KNIGHT"] = BLACK_KNIGHT
PieceImages["BLACK_KING"] = BLACK_KING
PieceImages["BLACK_BISHOP"] = BLACK_BISHOP

# group of every sprite
all_sprites = pygame.sprite.Group()

# add pieces
DefaultPieces()

# since game hasn't started yet, these things should be set by default
mouseClicked = False
drawn = False

# main game loop, start playing
while True:
        # keep loop running at the right speed
        clock.tick(FPS)
        for event in pygame.event.get():
                if event.type == QUIT:
                        pygame.quit()
                        sys.exit()
                        pygame.display.update()

                # when a tile is clicked, determine if piece is on tile
                # if a piece is on the clicked tile, confirm that a mouse button was clicked
                if event.type == MOUSEBUTTONDOWN:
                        mousex, mousey = event.pos
                        tile, piece = TilePressed(mousex, mousey)
                        if(piece == "e" or piece == None):
                            pass
                        else:
                            fromTile,fromPiece,toTile,toPiece, availableMoves, availableAttacks = getInput()
                            mouseClicked = True
                            print "A tile was clicked"
                            print fromTile,fromPiece,toTile,toPiece
                            ALL_PIECES[piece].update(fromTile,fromPiece,toTile,toPiece, availableMoves, availableAttacks)


        # Update
        
        
        # Draw / render
        Display()
        all_sprites.draw(DISPLAYSURF)
        # *after* drawing everything, flip the display
        pygame.display.flip()
    
