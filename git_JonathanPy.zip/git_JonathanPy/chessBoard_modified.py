import string

class ChessBoard:
	# Dictionary for every piece, DO NOT REMOVE WILL DESTABLIZE EVERYTHING
	ALL_PIECES = {}
	# Screen Settings
	WIDTH = 800
	HEIGHT = 480
	BoardDisplacement = (WIDTH-HEIGHT)/2
	FPS = 30
	WHITE = (255, 255, 255)
	# X-Axis Pixels
	X_Axis = {"H":442,"G":384,"F":326,"E":268,"D":210,"C":152,"B":95,"A":37}
	# Y-Axis Pixels set
	Y_Axis = {"8":37,"7":95,"6":152,"5":210,"4":268,"3":326,"2":384,"1":442}
	# Boundry of tiles
	XLeft = [BoardDisplacement + x - 25 for x in sorted(X_Axis.values())]
	XRight = [BoardDisplacement + x + 25 for x in sorted(X_Axis.values())]
	YTop = [x - 25 for x in sorted(Y_Axis.values())]
	YBottom = [x + 25 for x in sorted(Y_Axis.values())]
	# get list of X_Axis and Y_Axis keys
	X_keys = sorted(X_Axis.keys())
	Y_keys = sorted(Y_Axis.keys())
	Y_keys.reverse()
	# cords to place a piece
	TileCords = {}
	for i in X_keys:
		for j in Y_keys:
			TileCords[i+j] = (XLeft[X_keys.index(i)], YTop[Y_keys.index(j)])
			
	# dictionary of what's in a tile
	# not implemented in this program
	TileSpace = {}
	for i in X_keys:
		for j in Y_keys:
			TileSpace[i+j] = "e"

	def __init__(self,setupType=0):
		self.squares = [['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e'],\
						['e','e','e','e','e','e','e','e']]
						
		if setupType == 0:
			self.squares[0] = ['BLACK_ROOK','BLACK_KNIGHT','BLACK_BISHOP','BLACK_QUEEN','BLACK_KING','BLACK_BISHOP','BLACK_KNIGHT','BLACK_ROOK']
			self.squares[1] = ['BLACK_PAWN','BLACK_PAWN','BLACK_PAWN','BLACK_PAWN','BLACK_PAWN','BLACK_PAWN','BLACK_PAWN','BLACK_PAWN']
			self.squares[2] = ['e','e','e','e','e','e','e','e']
			self.squares[3] = ['e','e','e','e','e','e','e','e']
			self.squares[4] = ['e','e','e','e','e','e','e','e']
			self.squares[5] = ['e','e','e','e','e','e','e','e']
			self.squares[6] = ['WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN']
			self.squares[7] = ['WHITE_ROOK','WHITE_KNIGHT','WHITE_BISHOP','WHITE_QUEEN','WHITE_KING','WHITE_BISHOP','WHITE_KNIGHT','WHITE_ROOK']

		#Debugging set-ups
		#Testing IsLegalMove
		if setupType == 1:
			self.squares[0] = ['BLACK_ROOK','BLACK_KNIGHT','BLACK_BISHOP','BLACK_QUEEN','BLACK_KING','BLACK_BISHOP','BLACK_KNIGHT','BLACK_ROOK']
			self.squares[1] = ['e','e','e','e','e','e','e','e']
			self.squares[2] = ['e','e','e','e','e','e','e','e']
			self.squares[3] = ['e','e','e','e','e','e','e','e']
			self.squares[4] = ['e','e','e','e','e','e','e','e']
			self.squares[5] = ['e','e','e','e','e','e','e','e']
			self.squares[6] = ['WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN','WHITE_PAWN']
			self.squares[7] = ['WHITE_ROOK','WHITE_KNIGHT','WHITE_BISHOP','WHITE_QUEEN','WHITE_KING','WHITE_BISHOP','WHITE_KNIGHT','WHITE_ROOK']

		#Testing IsInCheck, Checkmate
		if setupType == 2:
			self.squares[0] = ['e','e','e','e','e','e','e','e']
			self.squares[1] = ['e','e','e','e','e','e','e','e']
			self.squares[2] = ['e','e','e','e','BLACK_KING','e','e','e']
			self.squares[3] = ['e','e','e','e','BLACK_ROOK','e','e','e']
			self.squares[4] = ['e','e','BLACK_BISHOP','e','e','e','WHITE_ROOK','e']
			self.squares[5] = ['e','e','e','e','e','e','e','e']
			self.squares[6] = ['WHITE_BISHOP','e','e','e','e','e','e','e']
			self.squares[7] = ['e','e','e','WHITE_KING','WHITE_QUEEN','e','WHITE_KNIGHT','e']

		#Testing Defensive AI
		if setupType == 3:
			self.squares[0] = ['e','e','e','e','e','e','e','e']
			self.squares[1] = ['e','e','e','e','e','e','e','e']
			self.squares[2] = ['e','e','e','e','BLACK_KING','e','e','e']
			self.squares[3] = ['e','e','e','e','BLACK_ROOK','e','e','e']
			self.squares[4] = ['e','e','BLACK_BISHOP','e','e','e','WHITE_ROOK','e']
			self.squares[5] = ['e','e','e','e','e','e','e','e']
			self.squares[6] = ['e','e','e','e','e','e','e','e']
			self.squares[7] = ['e','e','e','WHITE_KING','WHITE_QUEEN','e','WHITE_KNIGHT','e']			
			
	def GetState(self):
		return self.squares
		
	def ConvertMoveTupleListToAlgebraicNotation(self,moveTupleList):	
		newTupleList = []
		for move in moveTupleList:
			newTupleList.append((self.ConvertToAlgebraicNotation(move[0]),self.ConvertToAlgebraicNotation(move[1])))
		return newTupleList
	
	def ConvertSquareListToAlgebraicNotation(self,list):
		newList = []
		for square in list:
			newList.append(self.ConvertToAlgebraicNotation(square))
		return newList

	def ConvertToAlgebraicNotation(self,(row,col)):
		#Converts (row,col) to algebraic notation
		#(row,col) format used in Python Chess code starts at (0,0) in the upper left.
		#Algebraic notation starts in the lower left and uses "a..h" for the column.
		return  self.ConvertToAlgebraicNotation_col(col) + self.ConvertToAlgebraicNotation_row(row)
	
	def ConvertToAlgebraicNotation_row(self,row):
		#(row,col) format used in Python Chess code starts at (0,0) in the upper left.
		#Algebraic notation starts in the lower left and uses "a..h" for the column.	
		B = ['8','7','6','5','4','3','2','1']
		return B[row]
		
	def ConvertToAlgebraicNotation_col(self,col):
		#(row,col) format used in Python Chess code starts at (0,0) in the upper left.
		#Algebraic notation starts in the lower left and uses "a..h" for the column.	
		A = ['a','b','c','d','e','f','g','h']
		return A[col]
	
	def MovePiece(self,moveTuple):
                #EX: ((0,1),(7,1)) --> ("B8","B1")
                # A-H col, 1-8 row / (0,1) = (num index, letter index)
		fromSquare_r = moveTuple[0][0]
		fromSquare_c = moveTuple[0][1]
		toSquare_r = moveTuple[1][0]
		toSquare_c = moveTuple[1][1]
		A = ["A","B","C","D","E","F","G","H"]
		B = ["8","7","6","5","4","3","2","1"]
		fromSquare_L = A[fromSquare_c]
		fromSquare_N = B[fromSquare_r]
		toSquare_L = A[toSquare_c]
		toSquare_N = B[toSquare_r]
		fromTile = fromSquare_L+fromSquare_N
		toTile = toSquare_L+toSquare_N
		# get screen cords
		position = self.TileCords[toTile]
		print moveTuple
		print (fromSquare_L+fromSquare_N,toSquare_L+toSquare_N)
		print
##		new_fromSquare_c = A.index(fromSquare_r)
##		new_fromSquare_r = B.index(fromSquare_c)
##		new_toSquare_c = A.index(toSquare_r)
##		new_toSquare_r = B.index(toSquare_c)
##		print moveTuple
##		print ((new_fromSquare_r,new_fromSquare_c),(new_toSquare_r,new_toSquare_c))
##		print

		fromPiece = self.squares[fromSquare_r][fromSquare_c]
		toPiece = self.squares[toSquare_r][toSquare_c]

		self.squares[toSquare_r][toSquare_c] = fromPiece
		self.squares[fromSquare_r][fromSquare_c] = 'e'

		fromPiece_fullString = fromPiece
		toPiece_fullString = toPiece
		
		if toPiece == 'e':
			messageString = fromPiece_fullString+ " moves from "+self.ConvertToAlgebraicNotation(moveTuple[0])+\
						    " to "+self.ConvertToAlgebraicNotation(moveTuple[1])
		else:
			messageString = fromPiece_fullString+ " from "+self.ConvertToAlgebraicNotation(moveTuple[0])+\
						" captures "+toPiece_fullString+" at "+self.ConvertToAlgebraicNotation(moveTuple[1])+"!"
		
		#capitalize first character of messageString
		messageString = string.upper(messageString[0])+messageString[1:len(messageString)]
		
		return messageString, position

if __name__ == "__main__":
	
	cb = ChessBoard(0)
	board1 = cb.GetState()
##	for r in range(8):
##		print board1[r]
##	print ""
		
	print "Move piece test..."
	cb.MovePiece(((0,1),(7,1))) # ("B8","B1")
	board2 = cb.GetState()
##	for r in range(8):
##		print board2[r]
##	print ""
