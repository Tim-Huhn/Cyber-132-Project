import pygame
import os
import sys
import Tkinter
from ChessRules import ChessRules
from chessBoard_modified import ChessBoard
from ChessGameParams_modified import TkinterGameSetupParams
from ChessPlayer_modified import ChessPlayer
from pygame.locals import *

# pieces class
class Pieces(pygame.sprite.Sprite):
        # constructor
        def __init__(self, piece, position):
                pygame.sprite.Sprite.__init__(self)
                self.image = piece
                self.rect = self.image.get_rect()
                self.rect.topleft = position

        ###################
        # need to implement
        ###################
        def update(self):
                pass

class ChessGUI_pygame:
        # Dictionary for every piece, DO NOT REMOVE WILL DESTABLIZE EVERYTHING
        ALL_PIECES = {}
        # Screen Settings
        WIDTH = 800
        HEIGHT = 480
        BoardDisplacement = (WIDTH-HEIGHT)/2
        FPS = 30
        WHITE = (255, 255, 255)
        # X-Axis Pixels
        X_Axis = {"H":442,"G":384,"F":326,"E":268,"D":210,"C":152,"B":95,"A":37}
        # Y-Axis Pixels set
        Y_Axis = {"8":37,"7":95,"6":152,"5":210,"4":268,"3":326,"2":384,"1":442}
        # Boundry of tiles
        XLeft = [BoardDisplacement + x - 25 for x in sorted(X_Axis.values())]
        XRight = [BoardDisplacement + x + 25 for x in sorted(X_Axis.values())]
        YTop = [x - 25 for x in sorted(Y_Axis.values())]
        YBottom = [x + 25 for x in sorted(Y_Axis.values())]
        # get list of X_Axis and Y_Axis keys
        X_keys = sorted(X_Axis.keys())
        Y_keys = sorted(Y_Axis.keys())
        Y_keys = Y_keys.reverse()
        # cords to place a piece
        TileCords = {}
        for i in X_keys:
                for j in Y_keys:
                        TileCords[i+j] = (XLeft[X_keys.index(i)], YTop[Y_keys.index(j)])
        # dictionary of what's in a tile
        TileSpace = {}
        for i in X_keys:
                for j in Y_keys:
                        TileSpace[i+j] = "e"



        def __init__(self):
                #os.environ['SDL_VIDEO_CENTERED'] = '1' #should center pygame window on the screen
                self.Board = ChessBoard(0)
                self.Rules = ChessRules()
##              pygame.init()
##              pygame.display.init()
##              self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT), 0, 32)
##              self.boardStart_x = 50
##              self.boardStart_y = 50
##              pygame.display.set_caption('Python Chess')


                #self.textBox = ScrollingTextBox(self.screen,525,825,50,450)
##              self.LoadImages()
##              self.DefaultPieces()
                #pygame.font.init() - should be already called by pygame.init()
                #self.fontDefault = pygame.font.Font( None, 20 )

        # Function to dsiplay the contents of the game
        def SetUp(self):
                # get name and color
                GameParams = TkinterGameSetupParams()
                (player1Name, player1Color, player2Name, player2Color) = GameParams.GetGameSetupParams()
                self.player = [0,0]
                self.player[0] = ChessPlayer(player1Name,player1Color)
                self.player[1] = ChessPlayer(player2Name,player2Color)
                # setup pygame
                pygame.init()
                pygame.display.init()
                self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT), 0, 32)
                self.boardStart_x = 50
                self.boardStart_y = 50
                pygame.display.set_caption('Python Chess')
                self.LoadImages()
                self.DefaultPieces()
##              self.screen.fill(self.WHITE)
##              self.screen.blit(self.golfBackground,(0, 0))
##              self.screen.blit(self.chessboardIMG,(self.BoardDisplacement, 0))
                

        def ConvertToScreenCoords(self,chessSquareTuple):
                #converts a (row,col) chessSquare into the pixel location of the upper-left corner of the square
                (row,col) = chessSquareTuple
                A = ["A","B","C","D","E","F","G","H"]
                B = ["8","7","6","5","4","3","2","1"]
                square = A[col] + B[row]
                return self.TileCords[square]
                
##      def ConvertToChessCoords(self,screenPositionTuple):
##              #converts a screen pixel location (X,Y) into a chessSquare tuple (row,col)
##              #x is horizontal, y is vertical
##              #(x=0,y=0) is upper-left corner of the screen
##              (X,Y) = screenPositionTuple
##              row = (Y-self.boardStart_y) / self.square_size
##              col = (X-self.boardStart_x) / self.square_size
##              return (row,col)
        
        def LoadImages(self):
                self.square_size = 50 #all images must be images 50 x 50 pixels
                self.chessboardIMG = pygame.image.load(os.path.join("images","ChessBoard.jpg")).convert()
                self.golfBackground = pygame.image.load(os.path.join("images","GreenBackground.gif")).convert()
                self.GREEN_DOT = pygame.image.load(os.path.join("images","green_dot.gif")).convert()
                #"convert()" is supposed to help pygame display the images faster.  It seems to mess up transparency - makes it all black!
                #And, for this chess program, the images don't need to change that fast.
                self.BLACK_PAWN = pygame.image.load(os.path.join("images","black_pawn.gif")) 
                self.BLACK_ROOK = pygame.image.load(os.path.join("images","black_rook.gif"))
                self.BLACK_KNIGHT = pygame.image.load(os.path.join("images","black_knight.gif"))
                self.BLACK_BISHOP = pygame.image.load(os.path.join("images","black_bishop.gif"))
                self.BLACK_KING = pygame.image.load(os.path.join("images","black_king.gif"))
                self.BLACK_QUEEN = pygame.image.load(os.path.join("images","black_queen.gif"))
                self.WHITE_PAWN = pygame.image.load(os.path.join("images","white_pawn.gif"))
                self.WHITE_ROOK = pygame.image.load(os.path.join("images","white_rook.gif"))
                self.WHITE_KNIGHT = pygame.image.load(os.path.join("images","white_knight.gif"))
                self.WHITE_BISHOP = pygame.image.load(os.path.join("images","white_bishop.gif"))
                self.WHITE_KING = pygame.image.load(os.path.join("images","white_king.gif"))
                self.WHITE_QUEEN = pygame.image.load(os.path.join("images","white_queen.gif"))
                # adds images to dictionary
                self.PieceImages = {}
                self.PieceImages["WHITE_ROOK"] = self.WHITE_ROOK
                self.PieceImages["WHITE_QUEEN"] = self.WHITE_QUEEN
                self.PieceImages["WHITE_PAWN"] = self.WHITE_PAWN
                self.PieceImages["WHITE_KNIGHT"] = self.WHITE_KNIGHT
                self.PieceImages["WHITE_KING"] = self.WHITE_KING
                self.PieceImages["WHITE_BISHOP"] = self.WHITE_BISHOP
                self.PieceImages["BLACK_ROOK"] = self.BLACK_ROOK
                self.PieceImages["BLACK_QUEEN"] = self.BLACK_QUEEN
                self.PieceImages["BLACK_PAWN"] = self.BLACK_PAWN
                self.PieceImages["BLACK_KNIGHT"] = self.BLACK_KNIGHT
                self.PieceImages["BLACK_KING"] = self.BLACK_KING
                self.PieceImages["BLACK_BISHOP"] = self.BLACK_BISHOP


        def Draw(self,board,highlightSquares=[]):
                self.screen.fill(self.WHITE)
                self.screen.blit(self.golfBackground,(0, 0))
                self.screen.blit(self.chessboardIMG,(self.BoardDisplacement, 0))
                all_sprites.remove(self.screen)
                
                boardSize = len(board) #board should be square.  boardSize should be always 8 for chess, but I dislike "magic numbers" :)

##              #draw blank board
##              current_square = 0
##              for r in range(boardSize):
##                      for c in range(boardSize):
##                              (screenX,screenY) = self.ConvertToScreenCoords((r,c))
##                              if current_square:
##                                      self.screen.blit(self.brown_square,(screenX,screenY))
##                                      current_square = (current_square+1)%2
##                              else:
##                                      self.screen.blit(self.white_square,(screenX,screenY))
##                                      current_square = (current_square+1)%2
##
##                      current_square = (current_square+1)%2
                                
                #highlight squares if specified
                for square in highlightSquares:
                        (screenX,screenY) = self.ConvertToScreenCoords(square)
                        self.screen.blit(self.GREEN_DOT,(screenX,screenY))
                
                #draw pieces
                all_sprites.draw(self.screen)
                

                        
##              for r in range(boardSize):
##                      for c in range(boardSize):
##                              (screenX,screenY) = self.ConvertToScreenCoords((r,c))
##                              if board[r][c] == 'bP':
##                                      self.screen.blit(self.black_pawn,(screenX,screenY))
##                              if board[r][c] == 'bR':
##                                      self.screen.blit(self.black_rook,(screenX,screenY))
##                              if board[r][c] == 'bT':
##                                      self.screen.blit(self.black_knight,(screenX,screenY))
##                              if board[r][c] == 'bB':
##                                      self.screen.blit(self.black_bishop,(screenX,screenY))
##                              if board[r][c] == 'bQ':
##                                      self.screen.blit(self.black_queen,(screenX,screenY))
##                              if board[r][c] == 'bK':
##                                      self.screen.blit(self.black_king,(screenX,screenY))
##                              if board[r][c] == 'wP':
##                                      self.screen.blit(self.white_pawn,(screenX,screenY))
##                              if board[r][c] == 'wR':
##                                      self.screen.blit(self.white_rook,(screenX,screenY))
##                              if board[r][c] == 'wT':
##                                      self.screen.blit(self.white_knight,(screenX,screenY))
##                              if board[r][c] == 'wB':
##                                      self.screen.blit(self.white_bishop,(screenX,screenY))
##                              if board[r][c] == 'wQ':
##                                      self.screen.blit(self.white_queen,(screenX,screenY))
##                              if board[r][c] == 'wK':
##                                      self.screen.blit(self.white_king,(screenX,screenY))
                        
                pygame.display.flip()


        # gets what tile the mouse clicks EX: A1
        def TilePosition(self, MX, MY):
                x = ""
                y = ""
                for i in range(0, 8):
                        if (MX > self.XLeft[i] and MX < self.XRight[i]):
                                x = self.X_keys[i]

                        if (MY > self.YTop[i] and MY < self.YBottom[i]):
                                y = self.Y_keys[i]
                if (x in self.X_keys and y in self.Y_keys):
                        return x+y

        # sees what to do based on what is in clicked tile, returns what was on the tile
        def TilePressed(self,tile, MX, MY):
                # gets the tile that was clicked
                #tile = self.TilePosition(MX, MY)
                if tile == None:
                        pass
                # gets what is in the tile
##              elif tile in self.TileSpace.keys() :
##                      piece = self.TileSpace[tile]
                piece = "e"
                if (tile != None and piece != None) and tile in self.TileSpace.keys():
                        piece = self.TileSpace[tile]
                        print tile, piece
                        return tile, piece
##                else:
##                      piece = "e"

        
        # Default placement of chess pieces
        def DefaultPieces(self):
                ## White/Black Pawn
                for i in ["A", "B", "C", "D", "E", "F", "G", "H"]:
                        # black pawn
                        tile = (i + "7")
                        image = "BLACK_PAWN"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID
                        
                        # white pawn
                        tile = (i + "2")
                        image = "WHITE_PAWN"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID

                ## White/Black Rook
                for i in ["A", "H"]:
                        # black rook
                        tile = (i + "8")
                        image = "BLACK_ROOK"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID
                        
                        # white rook
                        tile = (i + "1")
                        image = "WHITE_ROOK"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID

                ## White/Black Knight
                for i in ["B", "G"]:
                        # black knight
                        tile = (i + "8")
                        image = "BLACK_KNIGHT"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID
                        
                        # white knight
                        tile = (i + "1")
                        image = "WHITE_KNIGHT"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID

                ## White/Black Bishop
                for i in ["C", "F"]:
                        # black bishop
                        tile = (i + "8")
                        image = "BLACK_BISHOP"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID
                        
                        # white bishop
                        tile = (i + "1")
                        image = "WHITE_BISHOP"
                        x,y = self.TileCords[tile]
                        print tile, image, x, y
                        PieceID = image + "_" + i
                        self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                        # add to sprites
                        all_sprites.add(self.ALL_PIECES[PieceID])
                        self.TileSpace[tile] = PieceID

                ## Black/White Queen
                i = "D"
                # black queen
                tile = (i + "8")
                image = "BLACK_QUEEN"
                x,y = self.TileCords[tile]
                print tile, image, x, y
                PieceID = image + "_" + i
                self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                # add to sprites
                all_sprites.add(self.ALL_PIECES[PieceID])
                self.TileSpace[tile] = PieceID
                
                # white queen
                tile = (i + "1")
                image = "WHITE_QUEEN"
                x,y = self.TileCords[tile]
                print tile, image, x, y
                PieceID = image + "_" + i
                self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                # add to sprites
                all_sprites.add(self.ALL_PIECES[PieceID])
                self.TileSpace[tile] = PieceID


                ## Black/White King
                i = "E"
                # black king
                tile = (i + "8")
                image = "BLACK_KING"
                x,y = self.TileCords[tile]
                print tile, image, x, y
                PieceID = image + "_" + i
                self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                # add to sprites
                all_sprites.add(self.ALL_PIECES[PieceID])
                self.TileSpace[tile] = PieceID
                
                # white king
                tile = (i + "1")
                image = "WHITE_KING"
                x,y = self.TileCords[tile]
                print tile, image, x, y
                PieceID = image + "_" + i
                self.ALL_PIECES[PieceID] = Pieces(self.PieceImages[image],(x,y))
                # add to sprites
                all_sprites.add(self.ALL_PIECES[PieceID])
                self.TileSpace[tile] = PieceID

        def GetPlayerInput(self,board,currentColor):
                # returns ((from_row,from_col),(to_row,to_col))
                fromSquareChosen = 0
                toSquareChosen = 0
                while not fromSquareChosen or not toSquareChosen:
                        squareClicked = []
                        piece = []
                        for e in pygame.event.get():
                                if e.type is KEYDOWN:
                                        if e.key is K_ESCAPE:
                                                fromSquareChosen = 0
                                                fromTuple = []
                                if e.type is MOUSEBUTTONDOWN:
                                        (mouseX,mouseY) = pygame.mouse.get_pos()
                                        print mouseX, mouseY
                                        squareClicked = self.TilePosition(mouseX, mouseY)
                                        if(piece == "e" or piece == None):
                                                pass
                                        elif (squareClicked != None):
                                                # squareClicked is in A1 form
                                                #EX: change "A1" to (7,0)
                                                fromSquare_r = squareClicked[1]
                                                fromSquare_c = squareClicked[0]
                                                A = ["A","B","C","D","E","F","G","H"]
                                                B = ["8","7","6","5","4","3","2","1"]
                                                new_fromSquare_r = A.index(fromSquare_c)
                                                new_fromSquare_c = B.index(fromSquare_r)
                                                squareClicked = (new_fromSquare_r,new_fromSquare_c)
                                                print squareClicked
                                        # check if invalid
                                        if squareClicked[0]<0 or squareClicked[0]>7 or squareClicked[1]<0 or squareClicked[1]>7:
                                                  squareClicked = [] #not a valid chess square
                                if e.type is QUIT: #the "x" kill button
                                        pygame.quit()
                                        sys.exit()
                                        pygame.display.update()

                        if not fromSquareChosen and not toSquareChosen:
                                self.Draw(board)
                                if squareClicked != []:
                                        #EX: (7,0) == (1,A)
                                        (r,c) = squareClicked
                                        if currentColor == 'black' and 'BLACK' in board[r][c]:
                                                if len(self.Rules.GetListOfValidMoves(board,currentColor,squareClicked))>0:
                                                        fromSquareChosen = 1
                                                        fromTuple = squareClicked
                                        elif currentColor == 'white' and 'WHITE' in board[r][c]:
                                                if len(self.Rules.GetListOfValidMoves(board,currentColor,squareClicked))>0:
                                                        fromSquareChosen = 1
                                                        fromTuple = squareClicked
                                                
                        elif fromSquareChosen and not toSquareChosen:
                                possibleDestinations = self.Rules.GetListOfValidMoves(board,currentColor,fromTuple)
                                self.Draw(board,possibleDestinations)
                                if squareClicked != []:
                                        #EX: (7,0) == (1,A)
                                        (r,c) = squareClicked
                                        if squareClicked in possibleDestinations:
                                                toSquareChosen = 1
                                                toTuple = squareClicked
                                elif currentColor == 'black' and 'BLACK' in board[r][c]:
                                        if squareClicked == fromTuple:
                                                fromSquareChosen = 0
                                        elif len(self.Rules.GetListOfValidMoves(board,currentColor,squareClicked))>0:
                                                fromSquareChosen = 1
                                                fromTuple = squareClicked
                                        else:
                                                fromSquareChosen = 0 #piece is of own color, but no possible moves
                                elif currentColor == 'white' and 'WHITE' in board[r][c]:
                                        if squareClicked == fromTuple:
                                                fromSquareChosen = 0
                                        elif len(self.Rules.GetListOfValidMoves(board,currentColor,squareClicked))>0:
                                                fromSquareChosen = 1
                                                fromTuple = squareClicked
                                        else:
                                                fromSquareChosen = 0
                                else: #blank square or opposite color piece not in possible destinations clicked
                                        fromSquareChosen = 0

                return (fromTuple,toTuple), piece


        def EndGame(self,board):
                self.PrintMessage("Press any key to exit.")
                self.Draw(board) #draw board to show end game status
                while 1:
                        for e in pygame.event.get():
                                if e.type is KEYDOWN:
                                        pygame.quit()
                                        sys.exit(0)
                                if e.type is QUIT:
                                        pygame.quit()
                                        sys.exit(0)


        
        def MainLoop(self):
                clock = pygame.time.Clock()
                currentPlayerIndex = 0
                turnCount = 0
                #while not self.Rules.IsCheckmate(self.Board.GetState(),self.player[currentPlayerIndex].color):
                while True:
                        # keep loop running at the right speed
                        clock.tick(game.FPS)
                        board = self.Board.GetState()
                        currentColor = 'white' #self.player[currentPlayerIndex].GetColor()
                        #hardcoded so that player 1 is always white
                        if currentColor == 'white':
                                turnCount = turnCount + 1
                        self.Draw(board)
                        #self.Gui.PrintMessage("")
                        #baseMsg = "TURN %s - %s (%s)" % (str(turnCount),self.player[currentPlayerIndex].GetName(),currentColor)
                        #self.Gui.PrintMessage("-----%s-----" % baseMsg)
                        if self.Rules.IsInCheck(board,currentColor):
                                #self.Gui.PrintMessage("Warning..."+self.player[currentPlayerIndex].GetName()+" ("+self.player[currentPlayerIndex].GetColor()+") is in check!")
                                print "in check"
                                
##                      if self.player[currentPlayerIndex].GetType() == 'AI':
##                              moveTuple = self.player[currentPlayerIndex].GetMove(self.Board.GetState(), currentColor) 
                        #else:
                        moveTuple, piece = self.GetPlayerInput(board,currentColor)
                        # moveTuple looks like ((0,1),(7,1))
                        moveReport, position = self.Board.MovePiece(moveTuple) #moveReport = string like "White Bishop moves from A1 to C3" (+) "and captures ___!"
                        if(piece == "e" or piece == None):
                                pass
                        else:
                                mouseClicked = True
                                print "A tile was clicked"
                                print tile
                                print piece
                                #all_sprites.remove(ALL_PIECES[piece])
                                self.ALL_PIECES[piece].rect.topleft = position

                        
                        all_sprites.update()
                        
                        #self.Gui.PrintMessage(moveReport)
                        print moveReport
                        currentPlayerIndex = (currentPlayerIndex+1)%2 #this will cause the currentPlayerIndex to toggle between 1 and 0
##                      if self.AIvsAI and self.AIpause:
##                              time.sleep(self.AIpauseSeconds)
                
                #self.Gui.PrintMessage("CHECKMATE!")
                print "CHECKMATE!"
                winnerIndex = (currentPlayerIndex+1)%2
                #self.Gui.PrintMessage(self.player[winnerIndex].GetName()+" ("+self.player[winnerIndex].GetColor()+") won the game!")
                self.EndGame(board)

# start game
game = ChessGUI_pygame()
# group of every sprite
all_sprites = pygame.sprite.Group()
# set up board and pieces
game.SetUp()
# start game loop
game.MainLoop()


### since game hasn't started yet, these things should be set by default
##mouseClicked = False
##
### main game loop, start playing
##while True:
##      # keep loop running at the right speed
##      clock.tick(game.FPS)
##      # Process input (events)
##      for event in pygame.event.get():
##              if event.type == QUIT:
##                      pygame.quit()
##                      sys.exit()
##                      pygame.display.update()
##
##              # when a tile is clicked, determine if piece is on tile
##              # if a piece is on the clicked tile, confirm that a mouse button was clicked
##              if event.type == MOUSEBUTTONDOWN:
##                      mousex, mousey = event.pos
##                      tile, piece = TilePressed(mousex, mousey)
##                      if(piece == "e" or piece == None):
##                          pass
##                      else:
##                          
##                          mouseClicked = True
##                          print "A tile was clicked"
##                          print tile
##                          print piece
##                          all_sprites.remove(ALL_PIECES[piece])
##                          game.TileSpace[tile] = "e"
##                      #PieceHolder = TilePressed(mousex, mousey, mouseClicked)
##
##                elif event.type == MOUSEBUTTONUP and mouseClicked == True:
##                        print "oh no"
##                        mouseClicked = False
##                        mousex, mousey = event.pos
##                        PieceHolder = TilePressed(mousex, mousey, mouseClicked)
##
##      # Update
##      all_sprites.update()
##      
##      # Draw / render
##      Display()
##      all_sprites.draw(DISPLAYSURF)
##      # *after* drawing everything, flip the display
##      pygame.display.flip()
##    


