import pygame, sys
from pygame.locals import *

pygame.init()

DISPLAYSURF = pygame.display.set_mode((800, 480), 0, 32)
WHITE = (255, 255, 255)
LeftBoardSides = pygame.Rect(10, 20, 200, 300)

chessboardIMG = pygame.image.load('ChessBoard.gif')
golfBackground = pygame.image.load('GreenBackground.gif')

pygame.display.set_caption('Chessboard')
while True: # main game loop
    DISPLAYSURF.fill(WHITE)
    DISPLAYSURF.blit(golfBackground,(0, 0))
    DISPLAYSURF.blit(chessboardIMG,((800-480)/2, 0))
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
            pygame.display.update()
    pygame.display.update()

